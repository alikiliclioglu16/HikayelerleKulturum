# Hikâyelerle Kültürüm

Amerika'da büyüyen 4–11 yaş arası çift dilli Türk çocukları için etkileşimli, açılır sayfalı (pop-up) resimli kitaplar. Her kitap bir Türk kültürü ögesini ve Türkiye Yüzyılı Maarif Modeli'nin değerlerini işler.

Bu sürümde **Bayram Sabahı**, **Nasreddin Hoca ve Kazan**, **Keloğlan ve Üç Tohum** ve **23 Nisan Şenliği** hazır; 15 kitaplık planın diğer 11 kitabı "Yakında" olarak listelenir (plan: `docs/kitap-plani.md`).

## Neler var?

- 3D ana sayfa: üst rafta 20 Türk kültürü ögesi (dokununca Türkçe adı okunur, kısa bir bilgi çıkar, Kelime Sandığı’na hazine olarak eklenir), alt rafta kitaplar. Raf parmakla kaydırılır, kitaplar oklarla değişir.
- Masanın üstünde açılan 3D kitap; her sayfada kâğıttan kesilmiş arka planlar ayağa kalkar, önlerinde 3D karakterler, hayvanlar ve nesneler durur (yürüyen, konuşan, sallanan modeller). Masada kültür rafındaki 3D nesneler (çaydanlık, buharı tüten çay, kahve, simit…) durur.
- Ana sayfada sakin bir ninni, her kitapta o kitabın ruhuna uygun kendi müziği: Bayram Sabahı'nda Rast makamında neşeli bir bayram havası (ney sesli flüt, kanun sesli arp, def), Nasreddin Hoca'da Hicaz makamında 9/8 bir karşılama (klarnet, darbuka, fagot), Keloğlan'da Uşşak makamında 6/8 bir masal havası (kaval sesli flüt, bağlama sesli gitar, kalimba), 23 Nisan'da 2/4 neşeli bir çocuk marşı (borazan, çan, davul). Sahnelerde hikâyeye uygun sesler çıkar: oyuncakların zıplaması, kapı çalınması, sihirli nesnelerin parıltısı, tencerenin tıngırdaması, yağmur ve gök gürültüsü, kuş ve cırcır böceği sesleri. Okurken sinematik kamera ve ışık hareketleri; "Sakin hareket" ayarı bunları durdurur.
- Ana sayfanın bütün duvarını kaplayan bir Türk halısı; fare hangi kitabın üstüne gelirse halı o kitabın desenine geçer.
- Okuyucu bir film çekimi gibi: kamera önce masanın üstünden iner, kitap açılırken geri çekilir, sonra açık kitaba yaklaşır. Kamera kitaba alçaktan, önden bakar: sol sayfada lale süslü, kobalt çerçeveli bir metin kartı pop-up gibi ayağa kalkar, sağ sayfada sahne canlanır; böylece hem yazı (kalın, siyah, büyük) hem karakterler, nesneler ve arka plan resmi tam karşıdan, net görünür. Kart kameraya dik döner, satırlar ekranda dümdüz durur; okunan kelime işaretlenir, sözlük kelimelerine kartın üstünden dokunulabilir. Sayfa çevrilirken kart da sahneyle birlikte katlanır ve yeniden kalkar. Dar telefon ekranlarında metin, okunabilsin diye alttaki kartta gösterilir. Sayfa çevrilirken kâğıt kıvrılır ve kâğıt sesi çıkar. Masada ana sayfadaki raftan nesneler durur: lale, çini, ebru, nazar boncuğu, lokum, mangala, bağlama ve kitaba göre çay takımı, simit, baklava; masanın kenarlarına, birbirini kapatmayacak biçimde dağılmışlardır: yakın çekimde kadraja girmezler, açılış ve sayfa çevirme çekimlerinde masanın tamamıyla görünürler.
- Site tamamen Türkçedir (İngilizce düğme ve açıklama yok).
- Bayram Sabahı'nda aile karakterleri (Elif, Can, Maya, Anne, Baba, Babaanne, Dede, Ayşe Teyze) iskeletli 3D modellerdir: anlatım ilerledikçe sayfadaki olaya göre hareket ederler (Elif yatağında uyanır, doğrulur, gerinir; Ayşe Teyze'nin elini öpüp alnına koyar). Konuşan karaktere kamera yumuşakça yönelir. Anlatım duraklatılınca hareketler de durur; "Tekrar oynat" sahneyi baştan oynatır.
- Türkçe metin: her kitap tek, tam metinle okunur. Houston Eğitim Ataşeliği logosu sol sayfada, metin kartının önüne basılıdır (telefonda sol sayfanın sağ alt köşesinde).
- Sesli okuma ve kelime kelime vurgulama (kaydı olan kitaplarda anlatıcının kendi sesiyle, diğerlerinde cihazın Türkçe sesiyle; ses yoksa kelimeler okuma hızında parlar).
- Altı noktalı kelimeye dokununca kelime okunur ve resimdeki nesne zıplar. Resimdeki nesneye dokununca da metindeki kelime parlar.
- "Biliyor musun?" kültür notları.
- Kelime Sandığı: yalnızca Türk kültürüne ait 32 hazine (lezzetler, sanat ve müzik, yerler ve yapılar, gelenekler, masal ve fıkra kahramanları). Kitapta bir kültür kelimesine ya da nesnesine, ana sayfada raftaki bir ögeye dokunulunca hazine sandığa girer. Bulunan hazineler resimleriyle, bulunmayanlar ipucuyla birlikte gölge olarak görünür; bir hazineye dokununca 3D modeli bir kaide üstünde döner (parmakla çevrilir) ve kültürümüzdeki yerini anlatan kısa metin okunur/dinlenir. Liste `src/treasures.ts` dosyasındadır (resimler `public/culture/hazine/`).
- Bilgi yarışması, değer avı ve ebeveynler için aile köşesi.
- Hesap, çerez, reklam ve analitik yok. İlerleme yalnızca tarayıcıda (localStorage) saklanır.

## GitHub'a yükleme ve yayın

1. Zip'teki her şeyi `Documents\GitHub\HikayelerleKulturum` klasörüne kopyalayın (README'nin üzerine yazılabilir).
2. GitHub Desktop'ta değişiklikleri görün, bir özet yazıp **Commit to main**, sonra **Push origin** deyin.
3. Vercel'de proje zaten bağlıysa her push sonrası site kendiliğinden güncellenir. İlk kez bağlıyorsanız Framework Preset olarak **Vite** seçilir; Build Command `npm run build`, Output Directory `dist`.

## Bilgisayarda çalıştırmak (isteğe bağlı)

[Node.js 20+](https://nodejs.org) kurulu olmalı.

```bash
npm install
npm run dev      # http://localhost:5173
npm run build    # yayın paketini dist/ klasörüne üretir
```

## Klasör yapısı

```
public/books/index.json            Raftaki kitaplar (hazır ve yakında)
public/books/bayram-sabahi/book.json   Kitabın bütün içeriği
public/culture/items.json          Kültür rafındaki 20 öge (ad, bilgi, isteğe bağlı 3D model)
src/home3d/                        3D ana sayfa: oda, raflar, geçici kültür modelleri, duvardaki kilim motifleri (kilim.ts)
src/art/                           Geçici çizimler (kod ile çizilen kâğıt-kesik sahneler)
src/three/bookScene.ts             3D masa, kitap, sayfa çevirme ve dokunma
src/pages/                         Ana sayfa, okuyucu, etkinlikler, sandık, ebeveyn sayfası
src/values.ts                      Maarif Modeli'nin 20 değeri
docs/gorsel-promptlari.md          ChatGPT/Gemini ve Meshy için hazır istemler
docs/kitap-plani.md                15 kitabın planı, değer dağılımı, kullanılacak 3D modeller ve lisans notları
public/models/aile, animals       Kitaplardaki iskeletli aile karakterleri ve hayvanlar
public/models/kapak               Canlı kitap kapakları (3D)
public/halilar                    Kitapların duvar halıları
```

## Yeni kitap eklemek

1. `public/books/<kitap-id>/book.json` dosyasını `bayram-sabahi/book.json` örneğine göre oluşturun.
2. `public/books/index.json` içine kitabı `"status": "ready"` ile ekleyin.

Metin işaretleme kuralı:

- `{lokum}` → sözlükte `lokum` olarak geçen kelime.
- `{yatağından|yatak}` → metinde "yatağından" görünür, sözlükte `yatak` aranır.
- Birden fazla kelime de olur: `{Ellerinizden öperim|ellerinizden öperim}`.

Her sayfada `text` alanı `tr` ve `en` içerir. Sayfanın `ambience` alanı (`"birds"` ya da `"crickets"`) sayfanın altında hafif kuş ya da cırcır böceği sesi çalar.

## Müzik ve sesler

Her kitabın müziği `public/books/<kitap>/muzik.mp3` dosyasıdır ve `book.json` içinde tanımlanır:

```json
"music": { "src": "/books/keloglan-tohum/muzik.mp3", "loop": 57.6 }
```

`loop`, dosyanın baştan kaç saniyesinin tekrar ettiğidir; sonrası yankının kuyruğudur ve bir sonraki turun üstüne biner, böylece müzik dikişsiz döner. Müzikler gerçek çalgı örnekleriyle (FluidR3 GM ses bankası, Frank Wen, CC BY 3.0) ve bilgisayarda üretilmiş darbuka, def ve davul sesleriyle hazırlandı; makam aralıkları (ör. Uşşak'ın segâh perdesi) çeyrek sese yakın inceltilerek çalındı. Raftaki çalgı ve zil sesleri (bağlama, davul, çan, cam boncuk, arp, borazan…) aynı ses bankasından kısa kayıtlardır (`public/sesler/raf/`); simit, kahve, buhar gibi çalgı olmayan sesler ve sahne sesleri `src/sfx.ts` içinde üretilir; bir beat'e `"sound": "knock"` yazılarak başka bir ses seçilebilir ya da `"sound": null` ile susturulabilir.

## Halı desenleri

Her kitabın halısı `public/books/index.json` içinde `carpet` ile seçilir. 15 kitabın halı resimleri `public/halilar/<kitap>.webp` klasöründedir:

```json
"carpet": { "motif": "kocboynuzu", "field": "#22406E", "border": "#8E2B24", "src": "/halilar/nasreddin-hoca-kazan.webp" }
```

Resim duvarın biçimine göre yeniden "dokunur": köşeler olduğu gibi kalır, bordürdeki desen tekrarları eklenip çıkarılır (desen esnemez), orta zemin aynalanarak genişletilir; altına saçak kodla eklenir. Bu yüzden halı her ekranda bordürüyle birlikte bütün duvarı kaplar. Yeni bir halı resmi aynı şablonda olmalı (bordür yüksekliğin yaklaşık %13'ü, genişliğin %10'u); farklıysa `"inset": [üst, sağ, alt, sol]` ile bordürün bittiği yer verilir. `motif` ise duvardaki motif yazısı ve resim yüklenemezse çizilen yedek halı içindir: `elibelinde`, `kocboynuzu`, `hayat-agaci`, `yildiz`, `goz`, `su-yolu`, `muska`, `pitrak`.

## Canlı kitap kapakları

Hazır kitapların kapakları 3D heykel kitaplardır (`public/models/kapak/<kitap>.glb`). Ana sayfada kapağın üstünden altın bir parıltı geçer, güneş ve tohumlar gibi noktalar parlar, küçük yıldızlar çakar; karakterler yerinde durur. İstenirse bir bölge hareket de ettirilebilir (aşağıdaki türler). Hangi bölgenin nasıl hareket edeceği `index.json` içinde `cover.live` ile yazılır (kapak koordinatları: sol 0 → sağ 1, alt 0 → üst 1):

```json
"cover": {
  "art": "cover-bayram", "src": "kapak.webp", "model": "/models/kapak/bayram-sabahi.glb", "color": "#0D3E86",
  "live": {
    "regions": [
      { "kind": "sway", "at": [0.33, 0.37], "r": [0.17, 0.29], "pivot": [0.33, 0.1], "amp": 0.05, "speed": 1.6 },
      { "kind": "hop", "at": [0.6, 0.33], "r": [0.13, 0.25], "amp": 0.018, "speed": 2.6 },
      { "kind": "glow", "at": [0.81, 0.6], "r": [0.05, 0.04], "amp": 0.35, "color": "#FFF2C2" }
    ],
    "twinkles": [[0.33, 0.42], [0.75, 0.62]]
  }
}
```

Hareket türleri: `sway` (pivot etrafında sallanma, el sallama), `bob` (yavaşça inip kalkma), `hop` (zıplama), `flutter` (dalgalanma), `glow` (parlayıp sönme). `kapak.webp` aynı kapağın düz resmidir; kitap kartında, okuyucudaki kapalı kitapta ve etkinliklerde kullanılır. "Sakin hareket" açıkken kapaklar durur.

## Kendi resimlerinizi kullanmak

Bir sayfaya `layers` eklenirse kodla çizilen geçici sahne yerine sizin resimleriniz kullanılır. Resimler arka planı şeffaf PNG veya WebP olmalı.

```json
"layers": [
  { "src": "art/p1-arka.webp", "z": 0.04, "w": 0.96, "h": 0.86 },
  { "src": "art/p1-orta.webp", "z": 0.45, "w": 0.92, "h": 0.60,
    "hotspots": [{ "word": "yatak", "rect": [0.1, 0.3, 0.8, 0.7] }] },
  { "src": "art/p1-on.webp",   "z": 0.84, "w": 0.94, "h": 0.30 }
]
```

- `z`: sayfanın arkasından (0) önüne (1) konum.
- `w`, `h`: genişlik ve yükseklik, sayfa genişliğine göre. Resim oranı `h / w` olmalı (arka katman için yaklaşık 1000×900 px).
- `hotspots`: dokunulabilir alanlar; `rect` = [x, y, genişlik, yükseklik], resmin sol üst köşesinden 0–1 arası.
- Kapak için `index.json` içinde `"cover": { "src": "art/kapak.webp" }` (oran 1 : 1,36).

İstemler için `docs/gorsel-promptlari.md` dosyasına bakın.

## Kültür rafına 3D model eklemek

Raftaki 20 nesnenin hepsi 3D modeldir (`public/models/culture/<id>.glb`, `public/culture/items.json` içinde `"model"`). Yeni bir model için GLB dosyasını bu klasöre koyup ögeye `"model": "/models/culture/<id>.glb"` ekleyin. Gerekirse `"rotY"` (derece), `"height"` (yükseklik) ve `"width"` (raftaki yer genişliği, varsayılan 0.46) ile yön ve boyut ayarlanır. Meshy dosyaları çok büyük gelirse (20 MB gibi) önce küçültülmeli; bunu Claude ile yapabilirsiniz. İstemler `docs/gorsel-promptlari.md` dosyasında.

## Sayfaya 3D model eklemek

Bir sayfaya `models` eklenirse GLB modeller açılır sayfanın üstünde durur ve dokununca kelimesi okunur:

```json
"models": [
  { "src": "/models/characters/nasreddin-hoca.glb", "word": "Nasreddin Hoca", "x": -0.36, "z": 0.66, "h": 0.42, "walkTo": [0.06, 0.6], "rotY": 90, "endRotY": 60 },
  { "src": "/models/characters/komsu.glb", "word": "komşu", "x": 0.3, "z": 0.5, "h": 0.41, "rotY": -40, "anim": "talk" },
  { "src": "/models/kenney/pot.glb", "word": "kazan", "x": 0.02, "z": 0.76, "h": 0.1, "w": 0.2, "tint": "#F0A060", "fx": "wobble" },
  { "src": "/models/kenney/tree-high-round.glb", "word": "ağaç", "x": -0.44, "z": 0.4, "h": 0.42, "fx": "sway" },
  { "src": "/models/animals/kedi-yuruyen.glb", "word": "kedi", "x": -0.4, "z": 0.95, "h": 0.12, "walkTo": [0.25, 0.95], "patrol": true, "speed": 0.06 }
]
```

- `x`: sayfa ortasına göre yatay konum (-0.5 … 0.5), `z`: arkadan (0) öne (1), `h`: yükseklik, `w`: en fazla genişlik (halı gibi yassı şeyler için), `y`: sayfadan yükseklik (masanın üstündeki çaydanlık gibi), `rotY`: dönüş (derece).
- `anim`: animasyon adı ya da bir parçası (`idle`, `talk`, `look`, `walk`), duruk için `"none"`.
- `walkTo`: model oraya yürür, sonra `anim` oynar ve `endRotY` yönüne döner. `patrol: true` ile iki nokta arasında gidip gelir.
- `fx`: duruk nesnelere hayat: `sway` (ağaç), `wobble` (titreyen kazan), `breathe` (saksı), `bob`, `swing`, `spin`.
- `tint`: modeli renklendirir (gri tencereyi bakır kazan yapmak gibi).
- `public/models/kenney/` içindeki hazır modeller Kenney kitlerinden (CC0) seçildi; yenileri eklenebilir.

Masadaki nesneler için `book.json` içine `table` eklenir (dünya birimi; kitap 2 birim genişliğinde):

```json
"table": [{ "src": "/models/culture/cay.glb", "word": "çay", "x": -1.3, "z": 0.56, "h": 0.2, "steam": true }]
```

Kod ile çizilen sahne katmanlarında `thumbOnly: true` olan katmanlar yalnızca etkinliklerdeki küçük resimlerde görünür (kitapta o rolü 3D modeller oynar).

## Hareket eden karakterler

Aile karakterleri `public/models/aile/` klasöründedir ve sayfalara `book.json` içindeki `cast`, `beats` ve `spots` alanlarıyla eklenir. Her hareket metindeki bir ipucu kelimesine bağlanır, anlatıcı o kelimeye gelince başlar:

```json
"cast": [{ "id": "elif", "x": 0.07, "z": 0.65, "y": 0.14, "rotY": -60, "pose": "lying", "lie": 1, "eyes": 0 }],
"beats": [
  { "cue": ["günaydın", "uyand"], "who": "elif", "do": "wake", "focus": true, "look": "up" },
  { "cue": ["fırladı"], "who": "elif", "do": "hopOut", "to": [-0.28, -0.14, 0.01], "face": 0 }
]
```

**Masalsı nesneler** de hikâyeye katılır: sayfadaki bir modele `id` verilirse (ör. `"id": "gunes"`) beat'ler onu da oynatır. Nesne hareketleri: `appear` (parıltıyla belirir), `vanish` (kaybolur), `rise` (yerine yükselir: doğan güneş), `sink` (alçalıp kaybolur: batan ay), `ring` (çalar saat gibi sallanır), `shine` (parlar), `grow` (topraktan büyüyerek çıkar: filiz, sebze), `rain` (bulut yağmur yağdırır), `spin` (döner). `"magic": true` olan nesnenin arkasında altın bir hale parlar, ara ara pırıldar ve hareket ederken yıldız izi bırakır; çocuk sihirli nesneyi hemen fark eder. `hidden: true` olan nesne başta görünmez, `from` başlangıçta yerinden ne kadar uzakta olduğunu söyler. `top` verilen model bir masadır (`"top": 0.67` → yüksekliğinin %67'si masa üstü): karakterlerin bıraktığı tepsi, tabak, şeker kâsesi masanın üstüne konur.

```json
{ "src": "/models/bayram/gunes.glb", "word": "güneş", "x": -0.25, "z": 0.1, "y": 0.64, "h": 0.12, "id": "gunes", "hidden": true, "from": [0, -0.05, 0], "fx": "bob" }
{ "cue": ["pencere", "güneş", "bugün"], "who": "gunes", "do": "rise" }
```

**Oyuncak karakterler:** `book.json` içinde `"toyCast": true` olan kitapta (Nasreddin Hoca ve Kazan, Keloğlan ve Üç Tohum, 23 Nisan Şenliği) karakterler bükülmez; oyuncak figür gibi bütün hâlinde zıplar, döner, eğilir, esner. Verilen eşya bir karakterden öbürüne yıldız iziyle uçar. Ayrıntılar `docs/karakterler.md` bölüm 7'de.

Dört kitabın sayfa arka planları `public/books/<kitap>/art/p1.webp … p8.webp` (sayfada `layers`). Bayram Sabahı'nın sayfa önündeki 3D eşyaları ve masalsı nesneleri `public/models/bayram/`, Nasreddin Hoca ile Keloğlan'ınkiler `public/models/masal/`, 23 Nisan'ınkiler (öğretmen, sınıf arkadaşları, bayrak, küre, Meclis maketi, balonlar…) `public/models/23-nisan/` klasöründedir. 23 Nisan'da havada uçuşan selam baloncukları `"proc": "bubble"` ve `"label"` ile yazılır; `"fx": "wave"` bayrağı dalgalandırır.

Hareketlerin listesi, alanların anlamı, modellerin incelemesi (iskelet ve animasyon yoktu, nasıl eklendi) ve sınırlar `docs/karakterler.md` dosyasındadır.

## Anlatıcı sesi

İlk altı kitap (Bayram Sabahı, Nasreddin Hoca ve Kazan, Keloğlan ve Üç Tohum, 23 Nisan Şenliği, Ebrunun Renkleri, Mahalle Fırını) kayıtlı anlatıcı sesiyle okunur. Her sayfanın kaydı `public/books/<kitap>/ses/p1.mp3 … p8.mp3` dosyasıdır ve sayfaya `audio` alanıyla bağlanır:

```json
"audio": { "src": "/books/bayram-sabahi/ses/p1.mp3", "marks": [0.27, 0.61, 1.03, …, 17.24], "ends": [0.6, 1.02, 1.6, …] }
```

- `marks`: metindeki her kelimenin kayıttaki başlangıç zamanı (saniye, okuma sırasıyla); en sondaki fazladan sayı son kelimenin bittiği andır. Okunan kelimenin parlaması ve sahnedeki hareketlerin başlaması (beat'lerin `cue` kelimeleri) bu zamanları izler.
- `ends`: her kelimenin bittiği an. Sayfadaki bir kelimeye ya da adı metinde geçen bir eşyaya dokununca o kelime anlatıcının kendi sesinden çalınır; kaydı olmayan sayfalarda cihazın sesi söyler.
- Okuma hızı ayarı kaydı da yavaşlatır ya da hızlandırır; sesin perdesi değişmez. Bütün sayfalar tek bir ses öğesiyle çalınır; telefonlarda ilk dokunuştan sonra kitap kendiliğinden sayfa sayfa okunmaya devam eder. Kayıt yüklenemezse sayfa cihazın sesiyle okunur.

Kayıtlar şöyle hazırlandı: başta 0,25 sn, sonda 0,4 sn sessizlik kalacak biçimde kırpıldı; ses seviyesi −16 LUFS'a getirildi (yumuşak bir sınırlayıcıyla gerçek tepe ≈ −2 dBTP); 96 kbps mono MP3 olarak kaydedildi. Kelime zamanları, kayıt üzerinde konuşma tanıma modeliyle (Omnilingual ASR 300M CTC) metnin harfleri hizalanarak çıkarıldı. Bu seviyeye göre kitap müziği yaklaşık 11 dB (anlatım sırasında 17 dB), sahne ve eşya sesleri 4–6 dB, mekân sesleri 19 dB aşağıda kalır.

Yeni kayıtlar `<kitap-adı>-sayfaN` adıyla (ör. `marti-ve-simit-sayfa1`) gelir; kırpma, seviye ve kelime zamanları her dosya için yeniden çıkarılır. Bir sayfanın metni değişirse kaydı da yenilenmelidir. Kaydı henüz olmayan kitaplar cihazın Türkçe sesiyle okunur.

## Kapadokya'nın Güzel Atları (7. kitap)

Sahne görselleri (`public/books/kapadokya/art/`) ortak kullanılır: 3–5. sayfalar `p3-*`, 6–7. sayfalar `p6-*`, 8. sayfanın zemini `p1-zemin`. 8. sayfadaki çocuk resmi üç katmandır: `resim/tay-resmi.webp`, Zeynep'in eklediği balon (`resim/balon-katmani.webp`, şeffaf) ve Elif'in yazdığı tarih (sitede boya kalemi gibi çizilir: `"proc": "writing", "label": "14 Haziran"`).

Yeni modeller gelene kadar geçici oyuncular:

| Gelecek model | Şimdilik |
|---|---|
| zeynep.glb | Maya'nın modeli (`CHARACTERS.zeynep`) |
| mustafa-amca.glb | Hasan amcanın modeli |
| ayten-hanim.glb | Ms. Carter'ın modeli |
| at-sahibi.glb | Köylü kadının modeli |
| tay-ayakta.glb, kisrak.glb | Kodla çizilmiş oyuncak atlar (`src/three/horses.ts`, `CHARACTERS.tay/kisrak` → `proc`) |
| tay-yatan.glb | Kodla çizilmiş yatan tay (`"proc": "tayYatan"`) |
| veteriner-cantasi.glb, su-matarasi.glb | Kodla çizilmiş çanta ve matara (`HELD.vetCantasi`, `HELD.matara`) |

Tel, yatan tayın uzanmış sağ ön bacağına ayrı nesne olarak konur (`"proc": "tel"`) ve 5. sayfada tay kurtarılınca kaybolur. Modeller `public/models/kapadokya/` klasörüne girince `CHARACTERS` içindeki `src` değerleri ve `proc` alanları değiştirilir.

Sesler: kısrak ve tay kişnemesi, nal sesleri ve telefon çalması `src/sfx.ts` içinde üretilir (`"sound": "kisneme" | "tayKisneme" | "nal" | "telefon"`).

## Güvenlik ve gizlilik

`vercel.json` içinde içerik güvenlik politikası (CSP) ve güvenlik başlıkları tanımlıdır. İleride dışarıdan bir analitik veya ödeme betiği eklenirse CSP'ye o alan adı eklenmelidir. Çocuklara yönelik bir üründe çerez kullanan analitik eklemeden önce gizlilik açısından hukuki görüş alın.

## Sonraki adımlar

- Resimlemeleri ChatGPT/Gemini ile üretip `layers` ile eklemek.
- Kalan kitapların anlatıcı kaydı (7–15).
- Kapadokya'nın Güzel Atları: Meshy modelleri gelince geçici oyuncular değiştirilecek (aşağıya bakın).
- Yeni kitaplar: sırada Martı ile Simit (`docs/kitap-plani.md`).
- Ebeveyn hesabı ve ödeme (Supabase + Stripe).
